package pkg234tree;

/**
 *
 * @author Chase Uphaus
 */
public class Main
{

    
    public static void main(String[] args)
    {
        int[] valuesToInsert = {1, 12, 8, 2, 25, 6, 14, 28, 17, 7, 52, 16, 48, 68, 3, 26, 29, 53, 55, 45};
        TwoThreeFour tree = new TwoThreeFour();
        for (int i = 0; i < valuesToInsert.length; i++)
        {
            tree.add(valuesToInsert[i]);
        }
        tree.add(70);
        System.out.println(tree.toString());
        tree.treeDisp();
    }
    
}
